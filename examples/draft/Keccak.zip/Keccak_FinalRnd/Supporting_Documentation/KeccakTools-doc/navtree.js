var NAVTREE =
[
  [ "KeccakTools", "index.html", [
    [ "Main Page", "index.html", null ],
    [ "Class List", "annotated.html", [
      [ "AffineSpaceIterator< T >", "class_affine_space_iterator.html", null ],
      [ "AffineSpaceOfRows", "class_affine_space_of_rows.html", null ],
      [ "AffineSpaceOfStates", "class_affine_space_of_states.html", null ],
      [ "Duplex", "class_duplex.html", null ],
      [ "DuplexException", "class_duplex_exception.html", null ],
      [ "Identity", "class_identity.html", null ],
      [ "Keccak", "class_keccak.html", null ],
      [ "KeccakException", "class_keccak_exception.html", null ],
      [ "KeccakF", "class_keccak_f.html", null ],
      [ "KeccakF25LUT", "class_keccak_f25_l_u_t.html", null ],
      [ "KeccakFCodeGen", "class_keccak_f_code_gen.html", null ],
      [ "KeccakFDCEquations", "class_keccak_f_d_c_equations.html", null ],
      [ "KeccakFDCLC", "class_keccak_f_d_c_l_c.html", null ],
      [ "KeccakFEquations", "class_keccak_f_equations.html", null ],
      [ "KeccakFPropagation", "class_keccak_f_propagation.html", null ],
      [ "ListOfRowPatterns", "class_list_of_row_patterns.html", null ],
      [ "MessageBlock", "class_message_block.html", null ],
      [ "MessageQueue", "class_message_queue.html", null ],
      [ "MultiRatePadding", "class_multi_rate_padding.html", null ],
      [ "OldDiversifiedKeccakPadding", "class_old_diversified_keccak_padding.html", null ],
      [ "PaddingRule", "class_padding_rule.html", null ],
      [ "Permutation", "class_permutation.html", null ],
      [ "ReverseStateIterator", "class_reverse_state_iterator.html", null ],
      [ "SimplePadding", "class_simple_padding.html", null ],
      [ "Sponge", "class_sponge.html", null ],
      [ "SpongeException", "class_sponge_exception.html", null ],
      [ "SymbolicBit", "class_symbolic_bit.html", null ],
      [ "SymbolicLane", "class_symbolic_lane.html", null ],
      [ "Trail", "class_trail.html", null ],
      [ "TrailException", "class_trail_exception.html", null ],
      [ "Transformation", "class_transformation.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "AffineSpaceIterator< T >", "class_affine_space_iterator.html", null ],
      [ "AffineSpaceOfRows", "class_affine_space_of_rows.html", null ],
      [ "AffineSpaceOfStates", "class_affine_space_of_states.html", null ],
      [ "Duplex", "class_duplex.html", null ],
      [ "DuplexException", "class_duplex_exception.html", null ],
      [ "KeccakException", "class_keccak_exception.html", null ],
      [ "KeccakFPropagation", "class_keccak_f_propagation.html", null ],
      [ "ListOfRowPatterns", "class_list_of_row_patterns.html", null ],
      [ "MessageBlock", "class_message_block.html", null ],
      [ "MessageQueue", "class_message_queue.html", null ],
      [ "PaddingRule", "class_padding_rule.html", [
        [ "MultiRatePadding", "class_multi_rate_padding.html", null ],
        [ "OldDiversifiedKeccakPadding", "class_old_diversified_keccak_padding.html", null ],
        [ "SimplePadding", "class_simple_padding.html", null ]
      ] ],
      [ "ReverseStateIterator", "class_reverse_state_iterator.html", null ],
      [ "Sponge", "class_sponge.html", [
        [ "Keccak", "class_keccak.html", null ]
      ] ],
      [ "SpongeException", "class_sponge_exception.html", null ],
      [ "SymbolicBit", "class_symbolic_bit.html", null ],
      [ "SymbolicLane", "class_symbolic_lane.html", null ],
      [ "Trail", "class_trail.html", null ],
      [ "TrailException", "class_trail_exception.html", null ],
      [ "Transformation", "class_transformation.html", [
        [ "Permutation", "class_permutation.html", [
          [ "Identity", "class_identity.html", null ],
          [ "KeccakF", "class_keccak_f.html", [
            [ "KeccakF25LUT", "class_keccak_f25_l_u_t.html", null ],
            [ "KeccakFCodeGen", "class_keccak_f_code_gen.html", null ],
            [ "KeccakFDCLC", "class_keccak_f_d_c_l_c.html", [
              [ "KeccakFDCEquations", "class_keccak_f_d_c_equations.html", null ]
            ] ],
            [ "KeccakFEquations", "class_keccak_f_equations.html", null ]
          ] ]
        ] ]
      ] ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "File List", "files.html", [
      [ "duplex.cpp", "duplex_8cpp.html", null ],
      [ "duplex.h", "duplex_8h.html", null ],
      [ "genKATShortMsg.cpp", "gen_k_a_t_short_msg_8cpp.html", null ],
      [ "Keccak-f.cpp", "_keccak-f_8cpp.html", null ],
      [ "Keccak-f.h", "_keccak-f_8h.html", null ],
      [ "Keccak-f25LUT.cpp", "_keccak-f25_l_u_t_8cpp.html", null ],
      [ "Keccak-f25LUT.h", "_keccak-f25_l_u_t_8h.html", null ],
      [ "Keccak-fAffineBases.cpp", "_keccak-f_affine_bases_8cpp.html", null ],
      [ "Keccak-fAffineBases.h", "_keccak-f_affine_bases_8h.html", null ],
      [ "Keccak-fCodeGen.cpp", "_keccak-f_code_gen_8cpp.html", null ],
      [ "Keccak-fCodeGen.h", "_keccak-f_code_gen_8h.html", null ],
      [ "Keccak-fDCEquations.cpp", "_keccak-f_d_c_equations_8cpp.html", null ],
      [ "Keccak-fDCEquations.h", "_keccak-f_d_c_equations_8h.html", null ],
      [ "Keccak-fDCLC.cpp", "_keccak-f_d_c_l_c_8cpp.html", null ],
      [ "Keccak-fDCLC.h", "_keccak-f_d_c_l_c_8h.html", null ],
      [ "Keccak-fEquations.cpp", "_keccak-f_equations_8cpp.html", null ],
      [ "Keccak-fEquations.h", "_keccak-f_equations_8h.html", null ],
      [ "Keccak-fParity.cpp", "_keccak-f_parity_8cpp.html", null ],
      [ "Keccak-fParity.h", "_keccak-f_parity_8h.html", null ],
      [ "Keccak-fParts.cpp", "_keccak-f_parts_8cpp.html", null ],
      [ "Keccak-fParts.h", "_keccak-f_parts_8h.html", null ],
      [ "Keccak-fPropagation.cpp", "_keccak-f_propagation_8cpp.html", null ],
      [ "Keccak-fPropagation.h", "_keccak-f_propagation_8h.html", null ],
      [ "Keccak-fTrails.cpp", "_keccak-f_trails_8cpp.html", null ],
      [ "Keccak-fTrails.h", "_keccak-f_trails_8h.html", null ],
      [ "Keccak.cpp", "_keccak_8cpp.html", null ],
      [ "Keccak.h", "_keccak_8h.html", null ],
      [ "main.cpp", "main_8cpp.html", null ],
      [ "padding.cpp", "padding_8cpp.html", null ],
      [ "padding.h", "padding_8h.html", null ],
      [ "sponge.cpp", "sponge_8cpp.html", null ],
      [ "sponge.h", "sponge_8h.html", null ],
      [ "transformations.cpp", "transformations_8cpp.html", null ],
      [ "transformations.h", "transformations_8h.html", null ],
      [ "types.h", "types_8h.html", null ]
    ] ],
    [ "File Members", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

