# The double of any number is even
Two proofs of the fact that x+x is even, for any natural number x.
