# Tower of Hanoi
A specification of the ["Tower of Hanoi" problem](https://en.wikipedia.org/wiki/Tower_of_Hanoi)
with the number of disk and towers defined by the model.